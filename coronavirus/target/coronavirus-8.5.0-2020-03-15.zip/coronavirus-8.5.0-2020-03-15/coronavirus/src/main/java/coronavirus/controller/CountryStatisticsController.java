package coronavirus.controller;

public class CountryStatisticsController {

}
